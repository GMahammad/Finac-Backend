window.addEventListener("message", (event) => {
  if (
    event.source === window &&
    event.data &&
    event.data.type === "TRIGGER_POSTBACK"
  ) {
    const { target, argument } = event.data;
    if (typeof __doPostBack === "function") {
      __doPostBack(target, argument);
    } else {
      console.warn("__doPostBack is not defined");
    }
  }
});
