let currentLoadingCount = 0;
let totalCount = 0;
let loadedProductCount = 0;
let totalProductCount = 0;
let statusText = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "SHOW_LOADING_TAB") {
    totalCount = message.text || 0;
    totalProductCount = message.productsCount || 0;
    currentLoadingCount = 0;
    loadedProductCount = 0;

    if (document.querySelector(".loading-tab")) return;

    const loadingTab = document.createElement("div");
    loadingTab.className = "loading-tab";
    Object.assign(loadingTab.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "100%",
      height: "100%",
      backgroundColor: "rgb(44, 44, 44)",
      color: "white",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      textAlign: "center",
      alignItems: "center",
      fontSize: "1.8rem",
      zIndex: "999999",
    });

    statusText = document.createElement("div");
    statusText.innerText = `Zəhmət olmasa gözləyin... \n 
     YGB yüklənir... (0 /${totalCount}) \n Malın sayı (0 / ${totalProductCount})`;

    const cancelButton = document.createElement("button");
    cancelButton.innerText = "Ləğv et";
    Object.assign(cancelButton.style, {
      marginTop: "20px",
      fontSize: "2rem",
      padding: "10px 20px",
      cursor: "pointer",
      backgroundColor: "white",
      color: "black",
      border: "none",
      borderRadius: "8px",
    });

    cancelButton.onclick = () => location.reload();

    loadingTab.appendChild(statusText);
    loadingTab.appendChild(cancelButton)
    document.body.appendChild(loadingTab);
  }

  if (message.type === "INCREASE") {
    currentLoadingCount++;
    if (statusText) {
      statusText.innerText = `Zəhmət olmasa gözləyin... \n 
        YGB yüklənir... (${currentLoadingCount} /${totalCount}) \n Malın sayı (${loadedProductCount} / ${totalProductCount})`;
    }
  }

  if (message.type === "INCREASE_PRODUCT") {
    loadedProductCount++;
    if (statusText) {
      statusText.innerText = `Zəhmət olmasa gözləyin... \n 
        YGB yüklənir... (${currentLoadingCount} /${totalCount}) \n Malın sayı (${loadedProductCount} / ${totalProductCount})`;
    }
  }

  if (message.type === "HIDE_LOADING_TAB") {
    const loadingTab = document.querySelector(".loading-tab");
    if (loadingTab) {
      loadingTab.remove();
      currentLoadingCount = 0;
      totalCount = 0;
      loadedProductCount = 0;
      totalProductCount = 0;
      statusText = null;
    } else {
      console.log("No loading tab found to remove");
    }
  }
});
